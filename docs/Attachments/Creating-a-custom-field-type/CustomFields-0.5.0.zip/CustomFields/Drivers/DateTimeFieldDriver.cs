﻿using System;
using JetBrains.Annotations;
using Orchard.ContentManagement;
using Orchard.ContentManagement.Drivers;
using Orchard.Core.ContentsLocation.Models;
using CustomFields.Settings;
using CustomFields.Fields;
using CustomFields.ViewModels;
using Orchard.Localization;

namespace CustomFields.Drivers {
    [UsedImplicitly]
    public class DateTimeFieldDriver : ContentFieldDriver<DateTimeField> {
        private const string TemplateName = "Fields/Common.DateTimeField";

        public DateTimeFieldDriver() {
            T = NullLocalizer.Instance;
        }

        public Localizer T { get; set; }

        private static string GetPrefix(ContentField field, ContentPart part) {
            return part.PartDefinition.Name + "." + field.Name;
        }

        protected override DriverResult Display(ContentPart part, Fields.DateTimeField field, string displayType) {
            var location = field.GetLocation(displayType, "primary", "1");

            var settings = field.PartFieldDefinition.Settings.GetModel<DateTimeFieldSettings>();
            var value = field.DateTime;

            var viewModel = new DateTimeFieldViewModel {
                Name = field.Name,
                Date = value.HasValue ? value.Value.ToShortDateString() : "",
                Time = value.HasValue ? value.Value.ToShortTimeString() : "",
                ShowDate = settings.Display == DateTimeFieldDisplays.DateAndTime || settings.Display == DateTimeFieldDisplays.DateOnly,
                ShowTime = settings.Display == DateTimeFieldDisplays.DateAndTime || settings.Display == DateTimeFieldDisplays.TimeOnly
            };

            return ContentFieldTemplate(viewModel, TemplateName, GetPrefix(field, part))
                .Location(location);
        }

        protected override DriverResult Editor(ContentPart part, Fields.DateTimeField field) {
            var location = field.GetLocation("Editor", "primary", "1");

            var settings = field.PartFieldDefinition.Settings.GetModel<DateTimeFieldSettings>();
            var value = field.DateTime;
            
            if(value.HasValue) {
                value = value.Value.ToLocalTime();
            }
            
            var viewModel = new DateTimeFieldViewModel {
                Name = field.Name,
                Date = value.HasValue ? value.Value.ToShortDateString() : "",
                Time = value.HasValue ? value.Value.ToShortTimeString() : "",
                ShowDate = settings.Display == DateTimeFieldDisplays.DateAndTime || settings.Display == DateTimeFieldDisplays.DateOnly,
                ShowTime = settings.Display == DateTimeFieldDisplays.DateAndTime || settings.Display == DateTimeFieldDisplays.TimeOnly

            };

            return ContentFieldTemplate(viewModel, TemplateName, GetPrefix(field, part))
                .Location(location);
        }

        protected override DriverResult Editor(ContentPart part, Fields.DateTimeField field, IUpdateModel updater) {
            var viewModel = new DateTimeFieldViewModel();

            if(updater.TryUpdateModel(viewModel, GetPrefix(field, part), null, null)) {
                DateTime value;

                var settings = field.PartFieldDefinition.Settings.GetModel<DateTimeFieldSettings>();
                if ( settings.Display == DateTimeFieldDisplays.DateOnly ) {
                    viewModel.Time = DateTime.Now.ToShortTimeString();
                }

                if ( settings.Display == DateTimeFieldDisplays.TimeOnly ) {
                    viewModel.Date = DateTime.Now.ToShortDateString();
                }

                if ( DateTime.TryParse(viewModel.Date + " " + viewModel.Time, out value) ) {
                    field.DateTime = value.ToUniversalTime();
                }
                else {
                    updater.AddModelError(GetPrefix(field, part), T("{0} is an invalid date and time", field.Name));
                    field.DateTime = null;
                }
            }
            
            return Editor(part, field);
        }
    }
}
