﻿using Orchard.ContentManagement;

namespace Orchard.LearnOrchard.FeaturedProduct.Models {
    public class FeaturedProductPart : ContentPart {
    }
}