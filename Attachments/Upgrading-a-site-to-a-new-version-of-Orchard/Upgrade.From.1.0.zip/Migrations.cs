using Orchard.Data.Migration;
using Orchard.Modules.Services;

namespace Upgrade.From10 {
    public class Migrations : DataMigrationImpl {
        private readonly IModuleService _moduleService;

        public Migrations(IModuleService moduleService) {
            _moduleService = moduleService;
        }

        public int Create() {
            _moduleService.EnableFeatures(new[] {"Orchard.Recipes"});

            return 1;
        }
    }
}